import pickle
from sklearn.linear_model import LinearRegression  # example
import numpy as np

# Example dummy data
X = np.array([[90, 80, 85, 5], [70, 60, 75, 3]])  # replace with real training data
y = np.array([88, 68])

model = LinearRegression()
model.fit(X, y)

# Save model
with open("student_model.pkl", "wb") as file:
    pickle.dump(model, file)
