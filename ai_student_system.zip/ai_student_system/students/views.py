import os
import joblib
from django.shortcuts import render

# Load the trained model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'student_model.pkl')

try:
    model = joblib.load(MODEL_PATH)
    print("✅ Model loaded successfully!")
except Exception as e:
    print("❌ Failed to load the model:", e)
    model = None

# This function must be at the top level (not inside try/except)
def predict_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        attendance = float(request.POST.get('attendance'))
        midterm = float(request.POST.get('midterm'))
        final = float(request.POST.get('final'))
        study_hours = float(request.POST.get('study_hours'))

        features = [[attendance, midterm, final, study_hours]]
        predicted_result = model.predict(features)[0] if model else "Model not loaded"

        return render(request, 'students/result.html', {
            'record': {
                'name': name,
                'predicted_result': predicted_result
            }
        })

    return render(request, 'students/form.html')
