from django.db import models

# Create your models here.
from django.db import models

class StudentRecord(models.Model):
    name = models.CharField(max_length=100)
    attendance = models.FloatField()
    midterm = models.FloatField()
    final = models.FloatField()
    study_hours = models.FloatField()
    predicted_result = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.name
